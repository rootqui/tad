﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamenFinal
{
    public partial class FrmBusqueda : Form
    {
        public DataGridViewRow objRow;
        public FrmBusqueda()
        {
            InitializeComponent();
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            objRow = DgvLista.SelectedRows[0];
            this.Close();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            objRow = null;
            this.Close();
        }

        public FrmBusqueda(Object objQuery, string objText)
        {
            InitializeComponent();
            this.Text = objText;
            DgvLista.DataSource = objQuery;
        }

        public FrmBusqueda(SqlDataReader objLector, string objText)
        {
            InitializeComponent();
            this.Text = objText;
            DataTable objTabla = new DataTable();
            objTabla.Load(objLector, LoadOption.OverwriteChanges);
            DgvLista.DataSource = objTabla;
        }

        private void FrmBusqueda_Load(object sender, EventArgs e)
        {

        }
    }
}
