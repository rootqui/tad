﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamenFinal
{
    public partial class FrmPregunta1 : Form
    {
        SqlConnection objConexion = new SqlConnection();
        SqlCommand objComando = new SqlCommand();
        SqlDataReader objReader;
        object objVersion;

        public FrmPregunta1()
        {
            InitializeComponent();
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            objConexion.Open();
            SqlTransaction objTran = objConexion.BeginTransaction();
            try
            {
                objComando.Transaction = objTran;
                objComando.CommandText = "uP_Insertar_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID_DOCUMENTO", CmbDocu.SelectedValue);
                objComando.Parameters.AddWithValue("@NUMERO_DOCUMENTO", TxtDocu.Text);
                objComando.Parameters.AddWithValue("@APELLIDO_PATERNO", TxtApePat.Text);
                objComando.Parameters.AddWithValue("@APELLIDO_MATERNO", TxtApeMat.Text);
                objComando.Parameters.AddWithValue("@NOMBRES", TxtNom.Text);
                objComando.Parameters.AddWithValue("@FECHA_NACIMIENTO", DtpFecha.Value);
                objComando.Parameters.AddWithValue("@ID_SEXO", CmbSexo.SelectedValue);
                objComando.Parameters.AddWithValue("@ID", 0).Direction = ParameterDirection.InputOutput;
                objComando.ExecuteNonQuery();

                int ID = (int)objComando.Parameters["@ID"].Value;

                foreach (DataGridViewRow fila in DgvCorreo.Rows)
                {
                    if (!fila.IsNewRow)
                    {
                        objComando.CommandText = "uP_Insertar_Correo_Persona";
                        objComando.Parameters.Clear();
                        objComando.Parameters.AddWithValue("@ID_PERSONA", ID);
                        objComando.Parameters.AddWithValue("@ID_CORREO", fila.Index + 1);
                        objComando.Parameters.AddWithValue("@CORREO", fila.Cells["CORREO"].Value);
                        objComando.ExecuteNonQuery();
                    }
                }

                foreach (DataGridViewRow fila in DgvTelefono.Rows)
                {
                    if (!fila.IsNewRow)
                    {
                        objComando.CommandText = "uP_Insertar_Telefono_Persona";
                        objComando.Parameters.Clear();
                        objComando.Parameters.AddWithValue("@ID_PERSONA", ID);
                        objComando.Parameters.AddWithValue("@ID_TELEFONO", fila.Index+ 1);
                        objComando.Parameters.AddWithValue("@TELEFONO", fila.Cells["TELEFONO"].Value);
                        objComando.ExecuteNonQuery();
                    }
                }

                objTran.Commit();
                MessageBox.Show("El registro se insertó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (SqlException sqlex)
            {
                objTran.Rollback();
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            objConexion.Open();
            SqlTransaction objTran = objConexion.BeginTransaction();
            try
            {
                objComando.Transaction = objTran;
                objComando.CommandText = "uP_Actualizar_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID", TxtID.Text);
                objComando.Parameters.AddWithValue("@ID_DOCUMENTO", CmbDocu.SelectedValue);
                objComando.Parameters.AddWithValue("@NUMERO_DOCUMENTO", TxtDocu.Text);
                objComando.Parameters.AddWithValue("@APELLIDO_PATERNO", TxtApePat.Text);
                objComando.Parameters.AddWithValue("@APELLIDO_MATERNO", TxtApeMat.Text);
                objComando.Parameters.AddWithValue("@NOMBRES", TxtNom.Text);
                objComando.Parameters.AddWithValue("@FECHA_NACIMIENTO", DtpFecha.Value);
                objComando.Parameters.AddWithValue("@ID_SEXO", CmbSexo.SelectedValue);
                objComando.Parameters.AddWithValue("@VERSION", objVersion);
                objComando.ExecuteNonQuery();

                objComando.CommandText = "uP_Eliminar_Correo_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID", TxtID.Text);
                objComando.ExecuteNonQuery();

                objComando.CommandText = "uP_Eliminar_Telefono_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID", TxtID.Text);
                objComando.ExecuteNonQuery();

                foreach (DataGridViewRow fila in DgvCorreo.Rows)
                {
                    if (!fila.IsNewRow)
                    {
                        objComando.CommandText = "uP_Insertar_Correo_Persona";
                        objComando.Parameters.Clear();
                        objComando.Parameters.AddWithValue("@ID_PERSONA", TxtID.Text);
                        objComando.Parameters.AddWithValue("@ID_CORREO", fila.Index + 1);
                        objComando.Parameters.AddWithValue("@CORREO", fila.Cells["CORREO"].Value);
                        objComando.ExecuteNonQuery();
                    }
                }

                foreach (DataGridViewRow fila in DgvTelefono.Rows)
                {
                    if (!fila.IsNewRow)
                    {
                        objComando.CommandText = "uP_Insertar_Telefono_Persona";
                        objComando.Parameters.Clear();
                        objComando.Parameters.AddWithValue("@ID_PERSONA", TxtID.Text);
                        objComando.Parameters.AddWithValue("@ID_TELEFONO", fila.Index + 1);
                        objComando.Parameters.AddWithValue("@TELEFONO", fila.Cells["TELEFONO"].Value);
                        objComando.ExecuteNonQuery();
                    }
                }
                objTran.Commit();
                MessageBox.Show("El registro se actualizó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (SqlException sqlex)
            {
                objTran.Rollback();
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            objConexion.Open();
            SqlTransaction objTran = objConexion.BeginTransaction();
            try
            {
                objComando.Transaction = objTran;
                objComando.CommandText = "uP_Eliminar_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID", TxtID.Text);
                objComando.ExecuteNonQuery();
                objTran.Commit();

                MessageBox.Show("El registro se eliminó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (SqlException sqlex)
            {
                objTran.Rollback();
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmPregunta1_Load(object sender, EventArgs e)
        {
            DataTable objDT_Docu = new DataTable();
            DataTable objDT_Sexo = new DataTable();
            try
            {
                SqlConnectionStringBuilder objConstructor = new SqlConnectionStringBuilder();
                objConstructor.DataSource = ".";
                objConstructor.InitialCatalog = "Final_2023_1";
                objConstructor.IntegratedSecurity = true;

                objConexion.ConnectionString =  objConstructor.ConnectionString;

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                DgvCorreo.Columns.Clear();
                DgvCorreo.Columns.Add("CORREO", "Correo");
                DgvCorreo.Rows.Clear();

                DgvTelefono.Columns.Clear();
                DgvTelefono.Columns.Add("TELEFONO", "Teléfono");
                DgvTelefono.Rows.Clear();

                objComando.CommandText = "uP_Lista_Documentos";
                objComando.Parameters.Clear();
                objConexion.Open();
                objReader = objComando.ExecuteReader();
                objDT_Docu.Load(objReader, LoadOption.OverwriteChanges);
                CmbDocu.DataSource = objDT_Docu;
                CmbDocu.ValueMember = "ID";
                CmbDocu.DisplayMember = "DESCRIPCION";

                objComando.CommandText = "uP_Lista_Sexos";
                objComando.Parameters.Clear();
                objReader = objComando.ExecuteReader();
                objDT_Sexo.Load(objReader, LoadOption.OverwriteChanges);
                CmbSexo.DataSource = objDT_Sexo;
                CmbSexo.ValueMember = "ID";
                CmbSexo.DisplayMember = "DESCRIPCION";
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnBuscaApeMat_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "uP_Ayuda_ApellidoMaterno";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@APELLIDO_MATERNO", TxtApeMat.Text);
                objConexion.Open();
                objReader = objComando.ExecuteReader();

                FrmBusqueda objBuscar = new FrmBusqueda(objReader, "Personas");
                objBuscar.ShowDialog(this);
                if(objBuscar.objRow != null)
                {
                    int ID = (int)objBuscar.objRow.Cells[0].Value;
                    CargarPersona(ID);
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnBuscaApePat_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "uP_Ayuda_ApellidoPaterno";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@APELLIDO_PATERNO", TxtApePat.Text);
                objConexion.Open();
                objReader = objComando.ExecuteReader();

                FrmBusqueda objBuscar = new FrmBusqueda(objReader, "Personas");
                objBuscar.ShowDialog(this);
                if (objBuscar.objRow != null)
                {
                    int ID = (int)objBuscar.objRow.Cells[0].Value;
                    CargarPersona(ID);
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void CargarPersona(int ID)
        {
            try
            {
                objComando.CommandText = "uP_Selecciona_Persona";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@ID", ID);
                objReader = objComando.ExecuteReader();
                if (objReader.HasRows)
                {
                    objReader.Read();
                    TxtID.Text = objReader.GetValue(objReader.GetOrdinal("ID")).ToString();
                    CmbDocu.SelectedValue = objReader.GetValue(objReader.GetOrdinal("ID_DOCUMENTO")).ToString();
                    TxtDocu.Text = objReader.GetValue(objReader.GetOrdinal("NUMERO_DOCUMENTO")).ToString();
                    TxtApePat.Text = objReader.GetValue(objReader.GetOrdinal("APELLIDO_PATERNO")).ToString();
                    TxtApeMat.Text = objReader.GetValue(objReader.GetOrdinal("APELLIDO_MATERNO")).ToString();
                    TxtNom.Text = objReader.GetValue(objReader.GetOrdinal("NOMBRES")).ToString();
                    DtpFecha.Value = Convert.ToDateTime(objReader.GetValue(objReader.GetOrdinal("FECHA_NACIMIENTO")));
                    CmbSexo.SelectedValue = objReader.GetValue(objReader.GetOrdinal("ID_SEXO")).ToString();
                    objVersion = objReader.GetValue(objReader.GetOrdinal("VERSION"));
                }
                objReader.NextResult();
                while (objReader.Read())
                {
                    DgvCorreo.Rows.Add(objReader.GetValue(objReader.GetOrdinal("CORREO")).ToString());
                }
                objReader.NextResult();
                while (objReader.Read())
                {
                    DgvTelefono.Rows.Add(objReader.GetValue(objReader.GetOrdinal("TELEFONO")).ToString());
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }
    }
}
