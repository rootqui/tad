﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace ExamenFinal
{
    public partial class FrmPregunta2 : Form
    {
        Final_2023_1Entities objEF = new Final_2023_1Entities();

        public FrmPregunta2()
        {
            InitializeComponent();
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    PERSONA objPER = new PERSONA();
                    objPER.ID_DOCUMENTO = Convert.ToByte(CmbDocu.SelectedValue);
                    objPER.NUMERO_DOCUMENTO = TxtDocu.Text;
                    objPER.APELLIDO_PATERNO = TxtApePat.Text;
                    objPER.APELLIDO_MATERNO = TxtApeMat.Text;
                    objPER.NOMBRES = TxtNom.Text;
                    objPER.FECHA_NACIMIENTO = DtpFecha.Value;
                    objPER.ID_SEXO = Convert.ToByte(CmbSexo.SelectedValue);

                    objEF.PERSONA.Add(objPER);
                    objEF.SaveChanges();

                    foreach (DataGridViewRow fila in DgvCorreo.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            PERSONA_CORREO objCOR = new PERSONA_CORREO();
                            objCOR.ID_PERSONA = objPER.ID;
                            objCOR.ID_CORREO = Convert.ToByte(fila.Index + 1);
                            objCOR.CORREO = fila.Cells["CORREO"].Value.ToString();
                            objEF.PERSONA_CORREO.Add(objCOR);
                        }
                    }

                    foreach (DataGridViewRow fila in DgvTelefono.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            PERSONA_TELEFONO objTEL = new PERSONA_TELEFONO();
                            objTEL.ID_PERSONA = objPER.ID;
                            objTEL.ID_TELEFONO = Convert.ToByte(fila.Index + 1);
                            objTEL.TELEFONO = fila.Cells["TELEFONO"].Value.ToString();
                            objEF.PERSONA_TELEFONO.Add(objTEL);
                        }
                    }
                    objEF.SaveChanges();
                    ts.Complete();
                }
                MessageBox.Show("El registro se insertó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    int ID = Convert.ToInt32(TxtID.Text);

                    var query = (from p in objEF.PERSONA where p.ID == ID select p).FirstOrDefault();

                    query.ID_DOCUMENTO = Convert.ToByte(CmbDocu.SelectedValue);
                    query.NUMERO_DOCUMENTO = TxtDocu.Text;
                    query.APELLIDO_PATERNO = TxtApePat.Text;
                    query.APELLIDO_MATERNO = TxtApeMat.Text;
                    query.NOMBRES = TxtNom.Text;
                    query.FECHA_NACIMIENTO = DtpFecha.Value;
                    query.ID_SEXO = Convert.ToByte(CmbSexo.SelectedValue);

                    var query1 = from c in objEF.PERSONA_CORREO where c.ID_PERSONA == ID select c;
                    foreach (PERSONA_CORREO fila in query1.ToList())
                    {
                        objEF.PERSONA_CORREO.Remove(fila);
                    }

                    var query2 = from t in objEF.PERSONA_TELEFONO where t.ID_PERSONA == ID select t;
                    foreach (PERSONA_TELEFONO fila in query2.ToList())
                    {
                        objEF.PERSONA_TELEFONO.Remove(fila);
                    }

                    foreach (DataGridViewRow fila in DgvCorreo.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            PERSONA_CORREO objCOR = new PERSONA_CORREO();
                            objCOR.ID_PERSONA = query.ID;
                            objCOR.ID_CORREO = Convert.ToByte(fila.Index + 1);
                            objCOR.CORREO = fila.Cells["CORREO"].Value.ToString();
                            objEF.PERSONA_CORREO.Add(objCOR);
                        }
                    }

                    foreach (DataGridViewRow fila in DgvTelefono.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            PERSONA_TELEFONO objTEL = new PERSONA_TELEFONO();
                            objTEL.ID_PERSONA = query.ID;
                            objTEL.ID_TELEFONO = Convert.ToByte(fila.Index + 1);
                            objTEL.TELEFONO = fila.Cells["TELEFONO"].Value.ToString();
                            objEF.PERSONA_TELEFONO.Add(objTEL);
                        }
                    }
                    objEF.SaveChanges();
                    ts.Complete();
                }
                MessageBox.Show("El registro se insertó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    int ID = Convert.ToInt32(TxtID.Text);

                    var query1 = from c in objEF.PERSONA_CORREO where c.ID_PERSONA == ID select c;
                    foreach (PERSONA_CORREO fila in query1.ToList())
                    {
                        objEF.PERSONA_CORREO.Remove(fila);
                    }

                    var query2 = from t in objEF.PERSONA_TELEFONO where t.ID_PERSONA == ID select t;
                    foreach (PERSONA_TELEFONO fila in query2.ToList())
                    {
                        objEF.PERSONA_TELEFONO.Remove(fila);
                    }

                    var query = (from p in objEF.PERSONA where p.ID == ID select p).FirstOrDefault();
                    objEF.PERSONA.Remove(query);

                    objEF.SaveChanges();
                    ts.Complete();
                }
                MessageBox.Show("El registro se insertó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmPregunta1_Load(object sender, EventArgs e)
        {
            try
            {
                DgvCorreo.Columns.Clear();
                DgvCorreo.Columns.Add("CORREO", "Correo");
                DgvCorreo.Rows.Clear();

                DgvTelefono.Columns.Clear();
                DgvTelefono.Columns.Add("TELEFONO", "Telefono");
                DgvTelefono.Rows.Clear();

                var query = from d in objEF.DOCUMENTO_IDENTIDAD select d;
                CmbDocu.DataSource = query.ToList();
                CmbDocu.ValueMember = "ID";
                CmbDocu.DisplayMember = "DESCRIPCION";

                var query1 = from s in objEF.SEXO select s;
                CmbSexo.DataSource = query1.ToList();
                CmbSexo.ValueMember = "ID";
                CmbSexo.DisplayMember = "DESCRIPCION";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void BtnBuscaApeMat_Click(object sender, EventArgs e)
        {
            try
            {
                var query = from p in objEF.PERSONA 
                            where p.APELLIDO_MATERNO.Contains(TxtApeMat.Text) 
                            select new {p.ID, p.APELLIDO_PATERNO, p.APELLIDO_MATERNO, p.NOMBRES};

                FrmBusqueda objetoAyuda = new FrmBusqueda(query.ToList(), "Personas");
                objetoAyuda.ShowDialog(this);

                if (objetoAyuda.objRow != null)
                {
                    int ID = Convert.ToInt32(objetoAyuda.objRow.Cells["ID"].Value);
                    CargarPersona(ID);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void BtnBuscaApePat_Click(object sender, EventArgs e)
        {
            try
            {
                var query = from p in objEF.PERSONA 
                            where p.APELLIDO_PATERNO.Contains(TxtApePat.Text) 
                            select new {p.ID, p.APELLIDO_PATERNO, p.APELLIDO_MATERNO, p.NOMBRES};

                FrmBusqueda objetoAyuda = new FrmBusqueda(query.ToList(), "Personas");
                objetoAyuda.ShowDialog(this);

                if (objetoAyuda.objRow != null)
                {
                    int ID = Convert.ToInt32(objetoAyuda.objRow.Cells["ID"].Value);
                    CargarPersona(ID);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }

        private void CargarPersona(int ID)
        {
            try
            {
                var query = (from p in objEF.PERSONA where p.ID == ID select p).FirstOrDefault(); 
                TxtID.Text = query.ID.ToString();
                CmbDocu.SelectedValue = query.ID_DOCUMENTO;
                TxtDocu.Text = query.NUMERO_DOCUMENTO;
                TxtApePat.Text = query.APELLIDO_PATERNO;
                TxtApeMat.Text = query.APELLIDO_MATERNO;
                TxtNom.Text = query.NOMBRES;
                DtpFecha.Value = query.FECHA_NACIMIENTO;
                CmbSexo.SelectedValue = query.ID_SEXO;

                foreach (PERSONA_CORREO objCOR in query.PERSONA_CORREO)
                {
                    DgvCorreo.Rows.Add(objCOR.CORREO);
                }

                foreach (PERSONA_TELEFONO objTEL in query.PERSONA_TELEFONO)
                {
                    DgvTelefono.Rows.Add(objTEL.TELEFONO);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
            }
        }
    }
}
