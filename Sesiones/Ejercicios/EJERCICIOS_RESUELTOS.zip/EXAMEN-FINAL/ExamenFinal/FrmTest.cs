﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinal
{
    public partial class FrmTest : Form
    {
        public FrmTest()
        {
            InitializeComponent();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            FrmPregunta2 loForm1 = new FrmPregunta2();
            loForm1.Show();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            FrmPregunta1 loForm1 = new FrmPregunta1();
            FrmPregunta1 loForm2 = new FrmPregunta1();
            loForm1.Show();
            loForm2.Show();
        }
    }
}
