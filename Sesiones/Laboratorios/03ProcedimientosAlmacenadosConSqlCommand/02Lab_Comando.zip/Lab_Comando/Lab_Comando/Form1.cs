﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_Comando
{
    public partial class Form1 : Form
    {
        SqlConnection objconexion = new SqlConnection();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            SqlConnectionStringBuilder objConstructorConexion = new SqlConnectionStringBuilder();
            objConstructorConexion.DataSource = ".";
            objConstructorConexion.InitialCatalog = "TAD";
            objConstructorConexion.IntegratedSecurity = true;

            objconexion.ConnectionString = objConstructorConexion.ConnectionString;
            

        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand objComando = new SqlCommand();

                //objComando.CommandType = CommandType.Text;
                //objComando.Connection = objconexion;
                //objComando.CommandText = "INSERT INTO PRODUCTO (CODIGO, DESCRIPCION) VALUES (2, 'MOUSE')";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objconexion;
                objComando.CommandText = "uP_Producto_Insertar";
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@CODIGO", TxtCodigo.Text);
                objComando.Parameters.AddWithValue("@DESCRIPCION", TxtDesc.Text);
                //objComando.Parameters.Add(); TP1-P1
                //objComando.Parameters.AddRange(); TP1-P1
                objconexion.Open();
                objComando.ExecuteNonQuery();
                MessageBox.Show("El registro se insertó.");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                objconexion.Close();
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand objComando = new SqlCommand();

                objComando.CommandType = CommandType.Text;
                objComando.Connection = objconexion;
                objComando.CommandText = "UPDATE PRODUCTO SET DESCRIPCION = 'TECLADO' WHERE CODIGO = 2";
                objconexion.Open();
                objComando.ExecuteNonQuery();
                objconexion.Close();
                MessageBox.Show("El registro se actualizó.");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand objComando = new SqlCommand();

                objComando.CommandType = CommandType.Text;
                objComando.Connection = objconexion;
                objComando.CommandText = "DELETE PRODUCTO WHERE CODIGO = 2";
                objconexion.Open();
                objComando.ExecuteNonQuery();
                objconexion.Close();
                MessageBox.Show("El registro se eliminó.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
