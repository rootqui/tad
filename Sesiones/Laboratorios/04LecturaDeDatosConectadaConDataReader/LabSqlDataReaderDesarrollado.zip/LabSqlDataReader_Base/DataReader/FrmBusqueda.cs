﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataReader
{
    public partial class FrmBusqueda : Form
    {
        public SqlDataReader objDR;
        public DataGridViewRow objRow;
        public FrmBusqueda()
        {
            InitializeComponent();
        }

        private void Busqueda_Load(object sender, EventArgs e)
        {
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
        }

        private void FrmBusqueda_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable objTabla = new DataTable();
                objTabla.Load(objDR);
                dataGridView1.DataSource = objTabla;
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            objRow = null;
            this.Close();
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            objRow = dataGridView1.SelectedRows[0];
            this.Close();
        }
    }
}
