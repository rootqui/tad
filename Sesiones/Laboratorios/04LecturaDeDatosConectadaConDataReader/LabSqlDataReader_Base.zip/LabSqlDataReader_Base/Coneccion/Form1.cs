﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coneccion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                ////EJEMPLO CON AUTENTICACION WINDOWS
                //SqlConnection objCon = new SqlConnection();
                //objCon.ConnectionString = "Server=.;Database=Lab_TAD;Integrated Security=SSPI;";
                //objCon.Open();

                ////EJEMPLO CON AUTENTICACION SQLSERVER
                //SqlConnection objCon = new SqlConnection();
                //objCon.ConnectionString = "Server=.;Database=Lab_TAD;User ID=arturo;Pwd=123456;";
                //objCon.Open();

                ////EJEMPLO CON AUTENTICACION SQLSERVER propiedad timeout
                //SqlConnection objCon = new SqlConnection();
                //objCon.ConnectionString = "Server=.;Database=Lab_TAD;User ID=arturo;Pwd=123456;Connection Timeout=15";
                //MessageBox.Show(objCon.ConnectionTimeout.ToString());
                //objCon.Open();

                ////EJEMPLO CON AUTENTICACION SQLSERVER propiedad encrypt 
                //SqlConnection objCon = new SqlConnection();
                //objCon.ConnectionString = "Server=.;Database=Lab_TAD;User ID=arturo;Pwd=123456;Encrypt=True;";
                //objCon.Open();

                //EJEMPLO CON CLASE SqlConnectionStringBuilder
                SqlConnectionStringBuilder ObjCsb = new SqlConnectionStringBuilder();
                ObjCsb.DataSource = ".";
                ObjCsb.InitialCatalog = "Lab_TAD";

                //ObjCsb.IntegratedSecurity = true; //aUTENTICACION WINDOWS

                ObjCsb.UserID = "ARTURO"; // aUTENTICACION SQL
                ObjCsb.Password = "123456"; // aUTENTICACION SQL

                SqlConnection objCon = new SqlConnection();
                objCon.ConnectionString = ObjCsb.ConnectionString;
                objCon.Open();

                //EJEMPLO CON ARCHIVO App.Config (TAREA)


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
