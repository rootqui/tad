﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_DataSet
{
    public partial class FrmUbigeo : Form
    {
        SqlConnection objConexion = new SqlConnection();

        public FrmUbigeo()
        {
            InitializeComponent();
        }

        private void FrmUbigeo_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder objConstructorCadenaConexion = new SqlConnectionStringBuilder();
                objConstructorCadenaConexion.DataSource = ".";
                objConstructorCadenaConexion.InitialCatalog = "Lab_TAD";
                objConstructorCadenaConexion.IntegratedSecurity = true;
                objConexion.ConnectionString = objConstructorCadenaConexion.ConnectionString;

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbProvincia_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbProvincia.SelectedValue is Int32)
            {
            }

        }

        private void CmbDepartamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbDepartamento.SelectedValue is Int32)
            {
            }
        }

        private void CmbDistrito_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbDistrito.SelectedValue is Int32)
            {

            }
        }
    }
}
