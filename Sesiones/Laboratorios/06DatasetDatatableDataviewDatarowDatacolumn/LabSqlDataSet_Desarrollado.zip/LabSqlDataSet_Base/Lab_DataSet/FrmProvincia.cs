﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_DataSet
{
    public partial class FrmProvincia : Form
    {
        SqlConnection objConexion = new SqlConnection();
        SqlDataAdapter objDA_Prov = new SqlDataAdapter();
        SqlDataAdapter objDA_Depa = new SqlDataAdapter();
        DataSet objDS = new DataSet();

        public FrmProvincia()
        {
            InitializeComponent();
        }

        private void FrmProvincia_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder objConstructorCadenaConexion = new SqlConnectionStringBuilder();
                objConstructorCadenaConexion.DataSource = ".";
                objConstructorCadenaConexion.InitialCatalog = "Lab_TAD";
                objConstructorCadenaConexion.IntegratedSecurity = true;
                objConexion.ConnectionString = objConstructorCadenaConexion.ConnectionString;

                objDA_Prov.SelectCommand = new SqlCommand("Seleccionar_Provincias", objConexion);
                objDA_Prov.SelectCommand.CommandType = CommandType.StoredProcedure;

                SqlCommandBuilder objConstructor = new SqlCommandBuilder(objDA_Prov);

                objDA_Prov.Fill(objDS,"prov");

                objDA_Depa.SelectCommand = new SqlCommand("Seleccionar_Departamentos", objConexion);
                objDA_Depa.SelectCommand.CommandType = CommandType.StoredProcedure;

                objDA_Depa.Fill(objDS, "depa");

                CmbDepartamento.DataSource = objDS.Tables["depa"];
                CmbDepartamento.ValueMember = "DEPA_ID";
                CmbDepartamento.DisplayMember = "DEPA_NOMBRE";

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DataRow_Prov = objDS.Tables["prov"].NewRow();
                DataRow_Prov["PROV_ID"] = Convert.ToInt32( objDS.Tables["prov"].Compute("max(PROV_ID)",string.Empty)) + 1;
                DataRow_Prov["DEPA_ID"] = CmbDepartamento.SelectedValue;
                DataRow_Prov["PROV_CODIGO"] = TxtCodigo.Text;
                DataRow_Prov["PROV_NOMBRE"] = TxtNombre.Text;

                objDS.Tables["prov"].Rows.Add(DataRow_Prov);

                MessageBox.Show("El registro se insertó", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DR_Prov = objDS.Tables["prov"].Select("PROV_ID = " + TxtID.Text)[0];
                DR_Prov["PROV_NOMBRE"] = TxtNombre.Text;
                DR_Prov["PROV_CODIGO"] = TxtCodigo.Text;
                DR_Prov["DEPA_ID"] = CmbDepartamento.SelectedValue;

                MessageBox.Show("El registro se actualizó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DR_Prov = objDS.Tables["prov"].Select("PROV_ID = " + TxtID.Text)[0];
                DR_Prov.Delete();

                MessageBox.Show("El registro se eliminó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSincronizar_Click(object sender, EventArgs e)
        {
            try
            {
                objDA_Prov.Update(objDS.Tables["prov"]); 
                MessageBox.Show("La sincronización se realizó satisfactoriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAyudaNombre_Click(object sender, EventArgs e)
        {
            try
            {
                DataView objDataView_Prov = objDS.Tables["prov"].DefaultView;
                objDataView_Prov.RowFilter = "PROV_NOMBRE LIKE '%" + TxtNombre.Text + "%'";
                FrmBusqueda objAyuda = new FrmBusqueda(objDataView_Prov);
                objAyuda.ShowDialog(this);
                if (objAyuda.objRow != null)
                {
                    int ID = Convert.ToInt32(objAyuda.objRow.Cells["PROV_ID"].Value);
                    DataRow DR_Prov = objDS.Tables["prov"].Select("PROV_ID = " + ID.ToString())[0];
                    TxtID.Text = DR_Prov["PROV_ID"].ToString();
                    TxtCodigo.Text = DR_Prov["PROV_CODIGO"].ToString();
                    TxtNombre.Text = DR_Prov["PROV_NOMBRE"].ToString();
                    CmbDepartamento.SelectedValue = DR_Prov["DEPA_ID"];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
