﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_TablaCompleja
{
    public partial class FrmRecursivo_Ubigeo : Form
    {
        SqlConnection objConexion = new SqlConnection();
        SqlCommand objComando = new SqlCommand();
        SqlDataReader objDataReader;

        public FrmRecursivo_Ubigeo()
        {
            InitializeComponent();
        }

        private void FrmRecursivo_Ubigeo_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder objConstructorCadenaConexion = new SqlConnectionStringBuilder();
                objConstructorCadenaConexion.DataSource = ".";
                objConstructorCadenaConexion.InitialCatalog = "TAD2020II";
                objConstructorCadenaConexion.IntegratedSecurity = true;
                objConexion.ConnectionString = objConstructorCadenaConexion.ConnectionString;

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                CargarArbolUbigeo();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void CargarArbolUbigeo()
        {
            try
            {
                // Ejecutar SP "Arbol_Ubigeo" para cargar treeview
                DataTable loDataTable = new DataTable();
                objComando.CommandText = "Arbol_Ubigeo";
                objComando.Parameters.Clear();
                objConexion.Open();
                objDataReader = objComando.ExecuteReader();
                loDataTable.Load(objDataReader, LoadOption.OverwriteChanges);


                TvwUbigeo.Nodes.Clear();

                TreeNode loNodoPadre = new TreeNode();
                loNodoPadre.Name = "0";
                loNodoPadre.Text = "Ubigeos";
                TvwUbigeo.Nodes.Add(loNodoPadre);

                CargarNodosHijos(loNodoPadre, loDataTable);
                TvwUbigeo.Nodes[0].ExpandAll();
                if (TvwUbigeo.Nodes.Count > 0)
                {
                    TvwUbigeo.SelectedNode = TvwUbigeo.Nodes[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }
        }
        private void CargarNodosHijos(TreeNode loNodoPadre, DataTable loDataTable)
        {
            TreeNode loNodoHijo;
            // Seleccionar filas hijas del nodo
            foreach (DataRow loRow in loDataTable.Select(string.Concat("UBIG_ID_FK = ", loNodoPadre.Name)))
            {
                loNodoHijo = new TreeNode();
                loNodoHijo.Name = loRow["UBIG_ID"].ToString();
                loNodoHijo.Text = loRow["UBIG_NOMBRE"].ToString();
                loNodoPadre.Nodes.Add(loNodoHijo);
                CargarNodosHijos(loNodoHijo, loDataTable);
            }
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                if (TvwUbigeo.SelectedNode != null)
                {
                    int liUBIG_ID_FK = 0;
                    if (TvwUbigeo.SelectedNode.Parent != null)
                    {
                        liUBIG_ID_FK = System.Convert.ToInt32(TvwUbigeo.SelectedNode.Name);
                    }
                    if (liUBIG_ID_FK == 0)
                    {
                        // el nodo padre es nulo DBNull.Value
                    }
                    else
                    {
                        // el nodo padre es liUBIG_ID_FK
                    }
                    MessageBox.Show("El registro se insertó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    CargarArbolUbigeo();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (TvwUbigeo.SelectedNode != null)
                {

                    int liUBIG_ID_FK = 0;
                    liUBIG_ID_FK = System.Convert.ToInt32(TvwUbigeo.SelectedNode.Parent.Name);
                    if (liUBIG_ID_FK == 0)
                    {
                        // el nodo padre es nulo DBNull.Value
                    }
                    else
                    {
                        // el nodo padre es liUBIG_ID_FK
                    }

                    MessageBox.Show("El registro se actualizó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    CargarArbolUbigeo();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Desea eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                    return;

                MessageBox.Show("El registro se eliminó satisfactóriamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                CargarArbolUbigeo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void TvwUbigeo_DoubleClick(object sender, EventArgs e)
        {
            if (Convert.ToInt32(TvwUbigeo.SelectedNode.Name) != 0)
            {
                DataTable loDataTable = new DataTable();
            }

        }

    }
}
