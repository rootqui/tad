﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabComando
{
    public partial class FrmProducto : Form
    {
        SqlConnection objConexion = new SqlConnection();
        SqlCommand objComando = new SqlCommand();

        public FrmProducto()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            objConexion.ConnectionString = "Server=.;DataBase=TAD2020;Integrated Security=SSPI";

        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Insertar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_NOMBRE", TxtNombre.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();

                MessageBox.Show("El registro se insertó", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information );
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Actualizar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_NOMBRE", TxtNombre.Text);
                objComando.Parameters.AddWithValue("@PROD_ID", TxtID.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();
                MessageBox.Show("El registro se actualizó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Eliminar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_ID", TxtID.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();
                MessageBox.Show("El registro se eliminó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

    }
}
