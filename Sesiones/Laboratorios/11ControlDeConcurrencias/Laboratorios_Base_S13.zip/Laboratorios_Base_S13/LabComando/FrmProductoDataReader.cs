﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabComando
{
    public partial class FrmProductoDataReader : Form
    {
        SqlConnection objConexion = new SqlConnection();
        SqlCommand objComando = new SqlCommand();
        SqlDataReader objLector;

        public FrmProductoDataReader()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            objConexion.ConnectionString = "Server=.;DataBase=TAD2020;Integrated Security=SSPI";
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Insertar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_NOMBRE", TxtNombre.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();

                MessageBox.Show("El registro se insertó", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information );
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Actualizar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_NOMBRE", TxtNombre.Text);
                objComando.Parameters.AddWithValue("@PROD_ID", TxtID.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();
                MessageBox.Show("El registro se actualizó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Eliminar_Producto";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_ID", TxtID.Text);
                objConexion.Open();
                objComando.ExecuteNonQuery();
                MessageBox.Show("El registro se eliminó.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }
        }

        private void BtnAyuda_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Seleccionar_Productos";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objConexion.Open();
                objLector = objComando.ExecuteReader();

                //Instanciar un objeto tipo formulario
                FrmBusqueda objAyuda = new FrmBusqueda();
                //envio de datareader a formulario de busqueda
                objAyuda.objDR = objLector;
                //Mostrar formulario en forma modal
                objAyuda.ShowDialog(this);
                //Verificar si usuario presiono aceptar o cancelar
                if (objAyuda.objRow != null)
                {
                    objComando.CommandText = "Seleccionar_UnProducto";
                    objComando.CommandType = CommandType.StoredProcedure;
                    objComando.Connection = objConexion;
                    objComando.Parameters.Clear();
                    objComando.Parameters.AddWithValue("@PROD_ID", objAyuda.objRow.Cells[0].Value.ToString());
                    //objConexion.Open();
                    objLector = objComando.ExecuteReader();
                    //preguntar si el datareader tiene registros
                    if (objLector.HasRows)
                    {
                        //leemos el primer registro
                        objLector.Read();
                        TxtID.Text = objLector.GetValue(objLector.GetOrdinal("PROD_ID")).ToString();
                        TxtNombre.Text = objLector.GetValue(objLector.GetOrdinal("PROD_NOMBRE")).ToString();
                    }

                }

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void BtnAyudaNombre_Click(object sender, EventArgs e)
        {
            try
            {
                objComando.CommandText = "Ayuda_Producto_LikeNombre";
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Connection = objConexion;
                objComando.Parameters.Clear();
                objComando.Parameters.AddWithValue("@PROD_NOMBRE", TxtNombre.Text);
                objConexion.Open();
                objLector = objComando.ExecuteReader();

                //Instanciar un objeto tipo formulario
                FrmBusqueda objAyuda = new FrmBusqueda();
                //envio de datareader a formulario de busqueda
                objAyuda.objDR = objLector;
                //Mostrar formulario en forma modal
                objAyuda.ShowDialog(this);
                //Verificar si usuario presiono aceptar o cancelar
                if (objAyuda.objRow != null)
                {
                    objComando.CommandText = "Seleccionar_UnProducto";
                    objComando.CommandType = CommandType.StoredProcedure;
                    objComando.Connection = objConexion;
                    objComando.Parameters.Clear();
                    objComando.Parameters.AddWithValue("@PROD_ID", objAyuda.objRow.Cells[0].Value.ToString());
                    //objConexion.Open();
                    objLector = objComando.ExecuteReader();
                    //preguntar si el datareader tiene registros
                    if (objLector.HasRows)
                    {
                        //leemos el primer registro
                        objLector.Read();
                        TxtID.Text = objLector.GetValue(objLector.GetOrdinal("PROD_ID")).ToString();
                        TxtNombre.Text = objLector.GetValue(objLector.GetOrdinal("PROD_NOMBRE")).ToString();
                    }

                }

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }

        }


    }
}
