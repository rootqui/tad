﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab1
{
    public partial class Form1 : Form
    {

        SqlConnection objConexion = new SqlConnection();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //objConexion.ConnectionString = "Server=.;DataBase=TAD2020;Integrated Security=SSPI";
                //objConexion.Open();
                //MessageBox.Show(objConexion.State.ToString());
                //objConexion.Close();

                //objConexion.ConnectionString = "Server=.;DataBase=TAD2020;User=tad;Pwd=123";
                //objConexion.Open();
                //MessageBox.Show(objConexion.State.ToString());
                //objConexion.Close();

                //objConexion.ConnectionString = "Server=.;DataBase=TAD2020;User=tad;Pwd=123";
                //objConexion.Open();
                //MessageBox.Show(objConexion.State.ToString());
                //MessageBox.Show(objConexion.ConnectionTimeout.ToString());
                //objConexion.Close();

                //objConexion.ConnectionString = "Server=.;DataBase=TAD2020;User=tad;Pwd=123;Connection Timeout=3";
                //objConexion.Open();
                //MessageBox.Show(objConexion.State.ToString());
                //MessageBox.Show(objConexion.ConnectionTimeout.ToString());
                //objConexion.Close();

                //objConexion.ConnectionString = "Server=.;DataBase=TAD2020;User=tad;Pwd=123;Encrypt=True;";
                //objConexion.Open();
                //MessageBox.Show(objConexion.State.ToString());
                //MessageBox.Show(objConexion.ConnectionTimeout.ToString());
                //objConexion.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }
    }
}
