﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabControlConcurrencia
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            FrmPValeConsumo objForm1 = new FrmPValeConsumo();
            objForm1.Text = objForm1.Text + " - Usuario 1";
            objForm1.Show(this);

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            FrmPValeConsumo objForm2 = new FrmPValeConsumo();
            objForm2.Text = objForm2.Text + " - Usuario 2";
            objForm2.Show(this);

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
