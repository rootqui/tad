﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabDataAdapter
{
    public partial class DataBinding : Form
    {
        private SqlConnection objConexion = new SqlConnection("Data Source=.;Initial Catalog=TAD2020;Integrated Security=SSPI;");
        private SqlCommand objComando = new SqlCommand();
        private DataSet objDato = new DataSet();
        private SqlDataAdapter objAdapter;
        private SqlCommandBuilder objComandoCons;
        public int posicion;

        public DataBinding()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }
        }
    }
}
