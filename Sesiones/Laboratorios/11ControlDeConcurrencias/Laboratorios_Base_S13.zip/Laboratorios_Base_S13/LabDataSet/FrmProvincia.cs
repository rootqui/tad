﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabDataSet
{
    public partial class FrmProvincia : Form
    {
        SqlConnection objConexion = new SqlConnection();

        SqlDataAdapter DA_Departamento = new SqlDataAdapter();
        DataTable DT_Departamento = new DataTable();

        SqlDataAdapter DA_Provincia = new SqlDataAdapter();
        DataTable DT_Provincia = new DataTable();

        public FrmProvincia()
        {
            InitializeComponent();
        }

        private void FrmProvincia_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder objConstructorCadenaConexion = new SqlConnectionStringBuilder();
                objConstructorCadenaConexion.DataSource = ".";
                objConstructorCadenaConexion.InitialCatalog = "TAD2020";
                objConstructorCadenaConexion.IntegratedSecurity = true;
                objConexion.ConnectionString = objConstructorCadenaConexion.ConnectionString;

                DA_Provincia.SelectCommand = new SqlCommand("Seleccionar_Provincia", objConexion);
                DA_Provincia.SelectCommand.CommandType = CommandType.StoredProcedure;
                DA_Provincia.Fill(DT_Provincia);
                SqlCommandBuilder builder = new SqlCommandBuilder(DA_Provincia);

                DA_Departamento.SelectCommand = new SqlCommand("Seleccionar_Departamento", objConexion);
                DA_Departamento.SelectCommand.CommandType = CommandType.StoredProcedure;
                DA_Departamento.Fill(DT_Departamento);

                CmbDepartamento.DataSource = DT_Departamento;
                CmbDepartamento.ValueMember = "DEPA_ID";
                CmbDepartamento.DisplayMember = "DEPA_NOMBRE";
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                objConexion.Close();
            }

        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DR_Provincia = DT_Provincia.NewRow();
                DR_Provincia["PROV_ID"] = Convert.ToInt32(DT_Provincia.Compute("Max([PROV_ID])", string.Empty)) + 1;
                DR_Provincia["PROV_NOMBRE"] = TxtNombre.Text;
                DR_Provincia["PROV_CODIGO"] = TxtCodigo.Text;
                DR_Provincia["DEPA_ID"] = CmbDepartamento.SelectedValue;
                DT_Provincia.Rows.Add(DR_Provincia);
                MessageBox.Show("El registro se insertó.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DR_Provincia = DT_Provincia.Select(string.Concat("PROV_ID =", TxtID.Text))[0];
                DR_Provincia["PROV_NOMBRE"] = TxtNombre.Text;
                DR_Provincia["PROV_CODIGO"] = TxtCodigo.Text;
                DR_Provincia["DEPA_ID"] = CmbDepartamento.SelectedValue;
                MessageBox.Show("El registro se actualizó.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow DR_Provincia = DT_Provincia.Select(string.Concat("PROV_ID =", TxtID.Text))[0];
                DR_Provincia.Delete();
                MessageBox.Show("El registro se eliminó.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSincronizar_Click(object sender, EventArgs e)
        {
            try
            {
                DA_Provincia.Update(DT_Provincia); 
                MessageBox.Show("La sincronización se realizó satisfactoriamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAyudaNombre_Click(object sender, EventArgs e)
        {
            try
            {
                DataView DV_Provincia = new DataView(DT_Provincia);
                DV_Provincia.RowFilter = string.Concat("PROV_NOMBRE LIKE '%", TxtNombre.Text, "%'");
                FrmBusqueda objBusqueda = new FrmBusqueda(DV_Provincia, "Provincias");
                objBusqueda.ShowDialog(this);
                if (objBusqueda.objRow != null)
                {
                    DataRow DR_Provincia = DT_Provincia.Select(string.Concat("PROV_ID =", objBusqueda.objRow.Cells[0].Value))[0];
                    TxtID.Text = DR_Provincia["PROV_ID"].ToString();
                    TxtNombre.Text = DR_Provincia["PROV_NOMBRE"].ToString();
                    TxtCodigo.Text = DR_Provincia["PROV_CODIGO"].ToString();
                    CmbDepartamento.SelectedValue = DR_Provincia["DEPA_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void CmbDepartamento_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
