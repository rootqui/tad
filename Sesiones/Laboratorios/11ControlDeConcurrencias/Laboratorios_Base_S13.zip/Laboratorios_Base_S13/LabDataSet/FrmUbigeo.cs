﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabDataSet
{
    public partial class FrmUbigeo : Form
    {
        SqlConnection objConexion = new SqlConnection();
        DataSet DS_Ubigeo = new DataSet();

        SqlDataAdapter DA_Departamento = new SqlDataAdapter();
        DataTable DT_Departamento = new DataTable();

        SqlDataAdapter DA_Provincia = new SqlDataAdapter();
        DataTable DT_Provincia = new DataTable();

        SqlDataAdapter DA_Distrito = new SqlDataAdapter();
        DataTable DT_Distrito = new DataTable();

        public FrmUbigeo()
        {
            InitializeComponent();
        }

        private void FrmUbigeo_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnectionStringBuilder objConstructorCadenaConexion = new SqlConnectionStringBuilder();
                objConstructorCadenaConexion.DataSource = ".";
                objConstructorCadenaConexion.InitialCatalog = "TAD2020";
                objConstructorCadenaConexion.IntegratedSecurity = true;
                objConexion.ConnectionString = objConstructorCadenaConexion.ConnectionString;

                CargarUbigeo();

                CmbDepartamento.DataSource = DT_Departamento;
                CmbDepartamento.ValueMember = "DEPA_ID";
                CmbDepartamento.DisplayMember = "DEPA_NOMBRE";
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CargarUbigeo()
        {
            try
            {
                DS_Ubigeo.Tables.Add(DT_Departamento);
                DA_Departamento.SelectCommand = new SqlCommand("Seleccionar_Departamento", objConexion);
                DA_Departamento.SelectCommand.CommandType = CommandType.StoredProcedure;
                DA_Departamento.Fill(DT_Departamento);

                DS_Ubigeo.Tables.Add(DT_Provincia);
                DA_Provincia.SelectCommand = new SqlCommand("Seleccionar_Provincia", objConexion);
                DA_Provincia.SelectCommand.CommandType = CommandType.StoredProcedure;
                DA_Provincia.Fill(DT_Provincia);

                DS_Ubigeo.Tables.Add(DT_Distrito);
                DA_Distrito.SelectCommand = new SqlCommand("Seleccionar_Distrito", objConexion);
                DA_Distrito.SelectCommand.CommandType = CommandType.StoredProcedure;
                DA_Distrito.Fill(DT_Distrito);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbProvincia_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbProvincia.SelectedValue is Int32)
            {
                DataView DV_Distrito = new DataView(DT_Distrito);
                DV_Distrito.RowFilter = string.Concat("PROV_ID = ", CmbProvincia.SelectedValue);

                CmbDistrito.DataSource = DV_Distrito;
                CmbDistrito.ValueMember = "DIST_ID";
                CmbDistrito.DisplayMember = "DIST_NOMBRE";

                DataRow DR_Provincia;
                DR_Provincia = DT_Provincia.Select(string.Concat("PROV_ID = ", CmbProvincia.SelectedValue))[0];
                TxtProv.Text = DR_Provincia["PROV_CODIGO"].ToString();
            }
            
        }

        private void CmbDepartamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbDepartamento.SelectedValue is Int32)
            {
                DataView DV_Provincia = new DataView(DT_Provincia);
                DV_Provincia.RowFilter = string.Concat("DEPA_ID = ", CmbDepartamento.SelectedValue);

                CmbProvincia.DataSource = DV_Provincia;
                CmbProvincia.ValueMember = "PROV_ID";
                CmbProvincia.DisplayMember = "PROV_NOMBRE";

                DataRow DR_Departamento;
                DR_Departamento = DT_Departamento.Select(string.Concat("DEPA_ID = ", CmbDepartamento.SelectedValue))[0];
                TxtDepa.Text = DR_Departamento["DEPA_CODIGO"].ToString();
            }
        }

        private void CmbDistrito_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CmbDistrito.SelectedValue is Int32)
            {
                DataRow DR_Distrito;
                DR_Distrito = DT_Distrito.Select(string.Concat("DIST_ID = ", CmbDistrito.SelectedValue))[0];
                TxtDist.Text = DR_Distrito["DIST_CODIGO"].ToString();
            }
        }
    }
}
