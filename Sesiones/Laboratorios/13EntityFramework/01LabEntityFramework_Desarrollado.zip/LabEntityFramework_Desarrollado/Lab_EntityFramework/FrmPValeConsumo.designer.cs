﻿namespace Lab_EntityFramework
{
    partial class FrmPValeConsumo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.BtnGrabar = new System.Windows.Forms.Button();
            this.BtnNuevo = new System.Windows.Forms.Button();
            this.BtnAyudaTrab = new System.Windows.Forms.Button();
            this.TxtNomTrab = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.DtpFec = new System.Windows.Forms.DateTimePicker();
            this.Label2 = new System.Windows.Forms.Label();
            this.TxtID = new System.Windows.Forms.TextBox();
            this.LblClave = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.CmbAlm = new System.Windows.Forms.ComboBox();
            this.TxtIDTrab = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnProdEliminar = new System.Windows.Forms.Button();
            this.BtnProdActualizar = new System.Windows.Forms.Button();
            this.BtnProdInsertar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.CmbCen = new System.Windows.Forms.ComboBox();
            this.TxtCant = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtIDProd = new System.Windows.Forms.TextBox();
            this.BtnAyudaProd = new System.Windows.Forms.Button();
            this.TxtNomProd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DgvDetalle = new System.Windows.Forms.DataGridView();
            this.BtnAyudaCon = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvDetalle)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.BtnEliminar.Location = new System.Drawing.Point(373, 422);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(75, 23);
            this.BtnEliminar.TabIndex = 38;
            this.BtnEliminar.Tag = "H";
            this.BtnEliminar.Text = "&Eliminar";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnGrabar
            // 
            this.BtnGrabar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.BtnGrabar.Location = new System.Drawing.Point(292, 422);
            this.BtnGrabar.Name = "BtnGrabar";
            this.BtnGrabar.Size = new System.Drawing.Size(75, 23);
            this.BtnGrabar.TabIndex = 37;
            this.BtnGrabar.Tag = "H";
            this.BtnGrabar.Text = "&Actualizar";
            this.BtnGrabar.UseVisualStyleBackColor = true;
            this.BtnGrabar.Click += new System.EventHandler(this.BtnGrabar_Click);
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.BtnNuevo.Location = new System.Drawing.Point(211, 422);
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Size = new System.Drawing.Size(75, 23);
            this.BtnNuevo.TabIndex = 36;
            this.BtnNuevo.Tag = "H";
            this.BtnNuevo.Text = "&Insertar";
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnAyudaTrab
            // 
            this.BtnAyudaTrab.Location = new System.Drawing.Point(522, 64);
            this.BtnAyudaTrab.Name = "BtnAyudaTrab";
            this.BtnAyudaTrab.Size = new System.Drawing.Size(24, 20);
            this.BtnAyudaTrab.TabIndex = 74;
            this.BtnAyudaTrab.TabStop = false;
            this.BtnAyudaTrab.Tag = "H";
            this.BtnAyudaTrab.Text = "...";
            this.BtnAyudaTrab.UseVisualStyleBackColor = true;
            this.BtnAyudaTrab.Click += new System.EventHandler(this.BtnAyudaTrab_Click);
            // 
            // TxtNomTrab
            // 
            this.TxtNomTrab.Location = new System.Drawing.Point(146, 65);
            this.TxtNomTrab.MaxLength = 300;
            this.TxtNomTrab.Name = "TxtNomTrab";
            this.TxtNomTrab.Size = new System.Drawing.Size(370, 20);
            this.TxtNomTrab.TabIndex = 73;
            this.TxtNomTrab.Tag = "HOL";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(12, 68);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(58, 13);
            this.Label6.TabIndex = 78;
            this.Label6.Text = "Trabajador";
            // 
            // DtpFec
            // 
            this.DtpFec.CustomFormat = "dd/MM/yyyy";
            this.DtpFec.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DtpFec.Location = new System.Drawing.Point(222, 11);
            this.DtpFec.Name = "DtpFec";
            this.DtpFec.Size = new System.Drawing.Size(96, 20);
            this.DtpFec.TabIndex = 72;
            this.DtpFec.Tag = "L";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(174, 15);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(37, 13);
            this.Label2.TabIndex = 77;
            this.Label2.Text = "Fecha";
            // 
            // TxtID
            // 
            this.TxtID.Location = new System.Drawing.Point(62, 12);
            this.TxtID.MaxLength = 300;
            this.TxtID.Name = "TxtID";
            this.TxtID.Size = new System.Drawing.Size(64, 20);
            this.TxtID.TabIndex = 71;
            this.TxtID.Tag = "HL";
            // 
            // LblClave
            // 
            this.LblClave.AutoSize = true;
            this.LblClave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblClave.Location = new System.Drawing.Point(12, 15);
            this.LblClave.Name = "LblClave";
            this.LblClave.Size = new System.Drawing.Size(44, 13);
            this.LblClave.TabIndex = 76;
            this.LblClave.Text = "Número";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(12, 41);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(48, 13);
            this.Label5.TabIndex = 75;
            this.Label5.Text = "Almacen";
            // 
            // CmbAlm
            // 
            this.CmbAlm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbAlm.FormattingEnabled = true;
            this.CmbAlm.Location = new System.Drawing.Point(62, 38);
            this.CmbAlm.Name = "CmbAlm";
            this.CmbAlm.Size = new System.Drawing.Size(305, 21);
            this.CmbAlm.TabIndex = 70;
            this.CmbAlm.Tag = "HO";
            // 
            // TxtIDTrab
            // 
            this.TxtIDTrab.Location = new System.Drawing.Point(76, 65);
            this.TxtIDTrab.MaxLength = 300;
            this.TxtIDTrab.Name = "TxtIDTrab";
            this.TxtIDTrab.Size = new System.Drawing.Size(64, 20);
            this.TxtIDTrab.TabIndex = 79;
            this.TxtIDTrab.Tag = "HL";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnProdEliminar);
            this.groupBox1.Controls.Add(this.BtnProdActualizar);
            this.groupBox1.Controls.Add(this.BtnProdInsertar);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.CmbCen);
            this.groupBox1.Controls.Add(this.TxtCant);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.TxtIDProd);
            this.groupBox1.Controls.Add(this.BtnAyudaProd);
            this.groupBox1.Controls.Add(this.TxtNomProd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.DgvDetalle);
            this.groupBox1.Location = new System.Drawing.Point(12, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(651, 316);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detalles";
            // 
            // BtnProdEliminar
            // 
            this.BtnProdEliminar.Location = new System.Drawing.Point(582, 132);
            this.BtnProdEliminar.Name = "BtnProdEliminar";
            this.BtnProdEliminar.Size = new System.Drawing.Size(61, 23);
            this.BtnProdEliminar.TabIndex = 95;
            this.BtnProdEliminar.Text = "Eliminar";
            this.BtnProdEliminar.UseVisualStyleBackColor = true;
            this.BtnProdEliminar.Click += new System.EventHandler(this.BtnProdEliminar_Click);
            // 
            // BtnProdActualizar
            // 
            this.BtnProdActualizar.Location = new System.Drawing.Point(582, 103);
            this.BtnProdActualizar.Name = "BtnProdActualizar";
            this.BtnProdActualizar.Size = new System.Drawing.Size(61, 23);
            this.BtnProdActualizar.TabIndex = 94;
            this.BtnProdActualizar.Text = "Actualizar";
            this.BtnProdActualizar.UseVisualStyleBackColor = true;
            this.BtnProdActualizar.Click += new System.EventHandler(this.BtnProdActualizar_Click);
            // 
            // BtnProdInsertar
            // 
            this.BtnProdInsertar.Location = new System.Drawing.Point(582, 74);
            this.BtnProdInsertar.Name = "BtnProdInsertar";
            this.BtnProdInsertar.Size = new System.Drawing.Size(61, 23);
            this.BtnProdInsertar.TabIndex = 93;
            this.BtnProdInsertar.Text = "Agregar";
            this.BtnProdInsertar.UseVisualStyleBackColor = true;
            this.BtnProdInsertar.Click += new System.EventHandler(this.BtnProdInsertar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(131, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 92;
            this.label4.Text = "Centro Costo";
            // 
            // CmbCen
            // 
            this.CmbCen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCen.FormattingEnabled = true;
            this.CmbCen.Location = new System.Drawing.Point(205, 47);
            this.CmbCen.Name = "CmbCen";
            this.CmbCen.Size = new System.Drawing.Size(305, 21);
            this.CmbCen.TabIndex = 91;
            this.CmbCen.Tag = "HO";
            // 
            // TxtCant
            // 
            this.TxtCant.Location = new System.Drawing.Point(59, 47);
            this.TxtCant.MaxLength = 300;
            this.TxtCant.Name = "TxtCant";
            this.TxtCant.Size = new System.Drawing.Size(64, 20);
            this.TxtCant.TabIndex = 90;
            this.TxtCant.Tag = "HL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 89;
            this.label3.Text = "Cantidad";
            // 
            // TxtIDProd
            // 
            this.TxtIDProd.Location = new System.Drawing.Point(59, 21);
            this.TxtIDProd.MaxLength = 300;
            this.TxtIDProd.Name = "TxtIDProd";
            this.TxtIDProd.Size = new System.Drawing.Size(64, 20);
            this.TxtIDProd.TabIndex = 88;
            this.TxtIDProd.Tag = "HL";
            // 
            // BtnAyudaProd
            // 
            this.BtnAyudaProd.Location = new System.Drawing.Point(505, 20);
            this.BtnAyudaProd.Name = "BtnAyudaProd";
            this.BtnAyudaProd.Size = new System.Drawing.Size(24, 20);
            this.BtnAyudaProd.TabIndex = 86;
            this.BtnAyudaProd.TabStop = false;
            this.BtnAyudaProd.Tag = "H";
            this.BtnAyudaProd.Text = "...";
            this.BtnAyudaProd.UseVisualStyleBackColor = true;
            this.BtnAyudaProd.Click += new System.EventHandler(this.BtnAyudaProd_Click);
            // 
            // TxtNomProd
            // 
            this.TxtNomProd.Location = new System.Drawing.Point(129, 21);
            this.TxtNomProd.MaxLength = 300;
            this.TxtNomProd.Name = "TxtNomProd";
            this.TxtNomProd.Size = new System.Drawing.Size(370, 20);
            this.TxtNomProd.TabIndex = 85;
            this.TxtNomProd.Tag = "HOL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 87;
            this.label1.Text = "Producto";
            // 
            // DgvDetalle
            // 
            this.DgvDetalle.AllowDrop = true;
            this.DgvDetalle.AllowUserToAddRows = false;
            this.DgvDetalle.AllowUserToDeleteRows = false;
            this.DgvDetalle.AllowUserToResizeColumns = false;
            this.DgvDetalle.AllowUserToResizeRows = false;
            this.DgvDetalle.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.DgvDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.DgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DgvDetalle.Location = new System.Drawing.Point(6, 74);
            this.DgvDetalle.MultiSelect = false;
            this.DgvDetalle.Name = "DgvDetalle";
            this.DgvDetalle.ReadOnly = true;
            this.DgvDetalle.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.DgvDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvDetalle.Size = new System.Drawing.Size(570, 236);
            this.DgvDetalle.TabIndex = 84;
            this.DgvDetalle.Tag = "HOL";
            this.DgvDetalle.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvDetalle_CellContentClick);
            this.DgvDetalle.DoubleClick += new System.EventHandler(this.DgvDetalle_DoubleClick);
            // 
            // BtnAyudaCon
            // 
            this.BtnAyudaCon.Location = new System.Drawing.Point(132, 12);
            this.BtnAyudaCon.Name = "BtnAyudaCon";
            this.BtnAyudaCon.Size = new System.Drawing.Size(24, 20);
            this.BtnAyudaCon.TabIndex = 85;
            this.BtnAyudaCon.TabStop = false;
            this.BtnAyudaCon.Tag = "H";
            this.BtnAyudaCon.Text = "...";
            this.BtnAyudaCon.UseVisualStyleBackColor = true;
            this.BtnAyudaCon.Click += new System.EventHandler(this.BtnAyudaCon_Click);
            // 
            // FrmPValeConsumo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 457);
            this.Controls.Add(this.BtnAyudaCon);
            this.Controls.Add(this.TxtIDTrab);
            this.Controls.Add(this.BtnAyudaTrab);
            this.Controls.Add(this.TxtNomTrab);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.DtpFec);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.TxtID);
            this.Controls.Add(this.LblClave);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.CmbAlm);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BtnGrabar);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmPValeConsumo";
            this.Text = "Vales de Consumo";
            this.Load += new System.EventHandler(this.FrmPValeConsumo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvDetalle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BtnEliminar;
        internal System.Windows.Forms.Button BtnGrabar;
        internal System.Windows.Forms.Button BtnNuevo;
        internal System.Windows.Forms.Button BtnAyudaTrab;
        internal System.Windows.Forms.TextBox TxtNomTrab;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.DateTimePicker DtpFec;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox TxtID;
        internal System.Windows.Forms.Label LblClave;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.ComboBox CmbAlm;
        internal System.Windows.Forms.TextBox TxtIDTrab;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.TextBox TxtIDProd;
        internal System.Windows.Forms.Button BtnAyudaProd;
        internal System.Windows.Forms.TextBox TxtNomProd;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.DataGridView DgvDetalle;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.ComboBox CmbCen;
        internal System.Windows.Forms.TextBox TxtCant;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button BtnAyudaCon;
        internal System.Windows.Forms.Button BtnProdEliminar;
        internal System.Windows.Forms.Button BtnProdActualizar;
        internal System.Windows.Forms.Button BtnProdInsertar;
    }
}