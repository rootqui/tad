﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabClienteWCF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            if (true)
            {
                MessageBox.Show("El registro se insertó.");
            }
            else
            {
                MessageBox.Show("Error al insertar el registro.");
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (true)
            {
                MessageBox.Show("El registro se actualizó.");
            }
            else
            {
                MessageBox.Show("Error al actualizar el registro.");
            }

        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (true)
            {
                MessageBox.Show("El registro se eliminó.");
            }
            else
            {
                MessageBox.Show("Error al eliminar el registro.");
            }

        }

        private void BtnAyudaID_Click(object sender, EventArgs e)
        {
            try
            {
                FrmBusqueda objayuda = new FrmBusqueda(DBNull.Value, "Busqueda de Usuarios");
                objayuda.ShowDialog(this);
                if (objayuda.objRow != null)
                {
                    int id = Convert.ToInt32(objayuda.objRow.Cells[2].Value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
