﻿using LabClienteWCF.ServicioTAD;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabClienteWCF
{
    public partial class Form1 : Form
    {
        ServicioTAD.Service1Client objWS = new ServicioTAD.Service1Client();

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnInsertar_Click(object sender, EventArgs e)
        {
            if (objWS.InsertarUsuario(TxtCorreo.Text, TxtClave.Text, TxtNombre.Text))
            {
                MessageBox.Show("El registro se insertó.");
            }
            else
            {
                MessageBox.Show("Error al insertar el registro.");
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (objWS.ActualizarUsuario(Convert.ToInt32(TxtID.Text), TxtCorreo.Text, TxtClave.Text, TxtNombre.Text))
            {
                MessageBox.Show("El registro se actualizó.");
            }
            else
            {
                MessageBox.Show("Error al actualizar el registro.");
            }

        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (objWS.EliminarUsuario(Convert.ToInt32(TxtID.Text)))
            {
                MessageBox.Show("El registro se eliminó.");
            }
            else
            {
                MessageBox.Show("Error al eliminar el registro.");
            }

        }

        private void BtnAyudaID_Click(object sender, EventArgs e)
        {
            try
            {
                List<USUARIO> usuarios = new List<USUARIO>();
                usuarios = objWS.AyudaUsuario().ToList();

                FrmBusqueda objayuda = new FrmBusqueda(usuarios, "Busqueda de Usuarios");
                objayuda.ShowDialog(this);
                if (objayuda.objRow != null)
                {
                    int id = Convert.ToInt32(objayuda.objRow.Cells[2].Value);
                    USUARIO usuario = new USUARIO();
                    usuario = objWS.SeleccionarUsuario(id);
                    TxtID.Text = usuario.ID.ToString();
                    TxtCorreo.Text = usuario.CORREO.ToString();
                    TxtNombre.Text = usuario.NOMBRE.ToString();
                    TxtClave.Text = usuario.CLAVE.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
